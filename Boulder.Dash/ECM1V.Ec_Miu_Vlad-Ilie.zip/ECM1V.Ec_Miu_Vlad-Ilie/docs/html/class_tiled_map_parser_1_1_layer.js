var class_tiled_map_parser_1_1_layer =
[
    [ "GetTileArray", "class_tiled_map_parser_1_1_layer.html#a2b775e9647a97d1acec4901d37d1da9e", null ],
    [ "ToString", "class_tiled_map_parser_1_1_layer.html#a1b94f8560063a0f0437db070ad8a6726", null ],
    [ "Data", "class_tiled_map_parser_1_1_layer.html#ae61048b501ecd02910fbc8f3a1568fe5", null ],
    [ "Height", "class_tiled_map_parser_1_1_layer.html#a3261f4323243567ae360792993c7cb60", null ],
    [ "Name", "class_tiled_map_parser_1_1_layer.html#aa6ae4e0b793766778338025be9b9e9f9", null ],
    [ "Width", "class_tiled_map_parser_1_1_layer.html#a39e43b303d7579265bd29cdf1d3bc763", null ]
];