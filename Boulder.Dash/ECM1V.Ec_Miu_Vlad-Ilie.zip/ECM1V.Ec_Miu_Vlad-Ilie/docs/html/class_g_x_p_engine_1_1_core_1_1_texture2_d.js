var class_g_x_p_engine_1_1_core_1_1_texture2_d =
[
    [ "Texture2D", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#aed1cea77e55afbc8d4f5ff0fb33468a8", null ],
    [ "Texture2D", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a65a9124d07cd68a2bc40d8d5ac78ef8a", null ],
    [ "Texture2D", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a5e9eabbdf8da42301e22896f37a453ef", null ],
    [ "Bind", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#aebcf2b1ed90b4ccfb915d7e9cfce6478", null ],
    [ "Clone", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a830ec300964c7f19b04d772c14796a89", null ],
    [ "Dispose", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a2d6872806dc76f9ec108696fac3b1bba", null ],
    [ "Unbind", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a703057ca56359b115b440071e9734355", null ],
    [ "UpdateGLTexture", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#aaf42dec1904d2cf4262b1a2e2de02c95", null ],
    [ "bitmap", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a2ada8510763b4e5bf8e0da3ede6d797e", null ],
    [ "filename", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#acdc6c106da4bd796222494ae2ab9dcf1", null ],
    [ "height", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#acfd524583e406b07b66b65b6e81aa81b", null ],
    [ "width", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a138395a6477c17da95c1dc1d3b315c88", null ],
    [ "wrap", "class_g_x_p_engine_1_1_core_1_1_texture2_d.html#a4f6e6dbeb4abc2f4884a2adcad291eff", null ]
];