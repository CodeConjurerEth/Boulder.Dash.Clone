var class_g_x_p_engine_1_1_core_1_1_window_size =
[
    [ "width", "class_g_x_p_engine_1_1_core_1_1_window_size.html#a765326eb989789d17b402d767d7f7b9a", null ]
];