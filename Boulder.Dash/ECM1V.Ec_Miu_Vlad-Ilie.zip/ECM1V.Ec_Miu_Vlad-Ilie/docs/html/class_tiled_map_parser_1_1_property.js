var class_tiled_map_parser_1_1_property =
[
    [ "ToString", "class_tiled_map_parser_1_1_property.html#ad036497c6e96cfc4c76384ad59f613f5", null ],
    [ "Name", "class_tiled_map_parser_1_1_property.html#adb72f48b664adb2973f8197c6f2ef4cf", null ],
    [ "Type", "class_tiled_map_parser_1_1_property.html#af25ad9e6a21fba626d60de2b4e2bb976", null ],
    [ "Value", "class_tiled_map_parser_1_1_property.html#a588b532fa981479b46146f6030647480", null ]
];