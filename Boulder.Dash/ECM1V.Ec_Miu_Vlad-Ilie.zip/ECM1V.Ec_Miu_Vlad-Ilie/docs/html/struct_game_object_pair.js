var struct_game_object_pair =
[
    [ "GameObjectPair", "struct_game_object_pair.html#a13385a784be2442ddcd095f44cc25f74", null ],
    [ "child", "struct_game_object_pair.html#a4cabdcada87a32a3d04b0b146aef3629", null ],
    [ "index", "struct_game_object_pair.html#a366d5de9cd3718b047dc709bc3ccb7fd", null ],
    [ "parent", "struct_game_object_pair.html#a6ae2e1ba3a16c073c883866947f704e5", null ]
];