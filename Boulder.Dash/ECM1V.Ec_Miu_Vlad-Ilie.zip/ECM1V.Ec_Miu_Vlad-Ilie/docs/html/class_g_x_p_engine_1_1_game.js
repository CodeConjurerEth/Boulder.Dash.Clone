var class_g_x_p_engine_1_1_game =
[
    [ "Game", "class_g_x_p_engine_1_1_game.html#a05983f154cc746b90c676e2f81b488a0", null ],
    [ "Destroy", "class_g_x_p_engine_1_1_game.html#a4763f40c236725a591e07f7e0ebfd264", null ],
    [ "GetDiagnostics", "class_g_x_p_engine_1_1_game.html#aa17a0f166621ac1e88f7abf51de41c90", null ],
    [ "Render", "class_g_x_p_engine_1_1_game.html#a719c9ad1c9b37a46f261e98d8d4fb4f3", null ],
    [ "RenderDelegate", "class_g_x_p_engine_1_1_game.html#a7f79e91eddcc16269d152c75007d6b4a", null ],
    [ "RenderSelf", "class_g_x_p_engine_1_1_game.html#a741e1ad53edfd4b48a0500f5e328b4ba", null ],
    [ "SetViewport", "class_g_x_p_engine_1_1_game.html#afecde817f37c96e76d26593c7fcac853", null ],
    [ "ShowMouse", "class_g_x_p_engine_1_1_game.html#a2f0f1eb7d0ba0c275deaef45421b8544", null ],
    [ "Start", "class_g_x_p_engine_1_1_game.html#a60cfaccee44dd4badd8629bcd9936beb", null ],
    [ "StepDelegate", "class_g_x_p_engine_1_1_game.html#a4d1f2cf034dc8d50480f94ea0da11fb4", null ],
    [ "PixelArt", "class_g_x_p_engine_1_1_game.html#a56bede5208383bcaf8ef73cfa5caf9c6", null ],
    [ "RenderMain", "class_g_x_p_engine_1_1_game.html#a48096b919243880eacca09c31cf9bbc6", null ],
    [ "currentFps", "class_g_x_p_engine_1_1_game.html#a689cb02d5dd37e307ea74816c15f0a59", null ],
    [ "height", "class_g_x_p_engine_1_1_game.html#a134c09653d9b6137a4762dc283a20883", null ],
    [ "RenderRange", "class_g_x_p_engine_1_1_game.html#a7c90cb7f4df63b1fbc651c878caf7ddf", null ],
    [ "targetFps", "class_g_x_p_engine_1_1_game.html#a39f9746072c114772bfbc278d3af5d70", null ],
    [ "width", "class_g_x_p_engine_1_1_game.html#a0a659aa4d59ed3729fc5d255651aac26", null ],
    [ "OnAfterRender", "class_g_x_p_engine_1_1_game.html#a5a3e69093d702335622c94d8550562d2", null ],
    [ "OnAfterStep", "class_g_x_p_engine_1_1_game.html#a21eda1f7129c978fa7f28cd502d7ae5f", null ],
    [ "OnBeforeStep", "class_g_x_p_engine_1_1_game.html#ae93f01e15a6ff137b4c2aba5449987e5", null ]
];