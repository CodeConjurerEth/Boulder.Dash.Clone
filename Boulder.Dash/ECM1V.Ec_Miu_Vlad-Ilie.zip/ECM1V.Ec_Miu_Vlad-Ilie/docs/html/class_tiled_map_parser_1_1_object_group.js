var class_tiled_map_parser_1_1_object_group =
[
    [ "ToString", "class_tiled_map_parser_1_1_object_group.html#aca6fc23130dbd6edd892a097f814e66a", null ],
    [ "Name", "class_tiled_map_parser_1_1_object_group.html#a224ae2834540864c8f09a54aaf3812eb", null ],
    [ "Objects", "class_tiled_map_parser_1_1_object_group.html#a504c2b25bdb3b766192af1709016a536", null ]
];