var class_g_x_p_engine_1_1_window =
[
    [ "Window", "class_g_x_p_engine_1_1_window.html#a09b4d4bc3799ef46d814f13cd4df1bc9", null ],
    [ "RenderWindow", "class_g_x_p_engine_1_1_window.html#a610825a7ed2a81be3ab9fd7fe7e51760", null ],
    [ "camera", "class_g_x_p_engine_1_1_window.html#aa1a9b5ac06f2ee93ad36e69c9dcb680c", null ],
    [ "height", "class_g_x_p_engine_1_1_window.html#a6f595c82175b25631e221cb56b006197", null ],
    [ "width", "class_g_x_p_engine_1_1_window.html#af9ce97573dc94e37fe3662ecc7ba8221", null ],
    [ "windowX", "class_g_x_p_engine_1_1_window.html#a831f8f665dd57d7bf56942fea0fe2f40", null ],
    [ "windowY", "class_g_x_p_engine_1_1_window.html#aa7ea3483bb539781fc2ceaa09d1a1c44", null ]
];