var class_g_x_p_engine_1_1_core_1_1_g_l_context =
[
    [ "GLContext", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a63cba528538a79ab3fcdd095f2b5e2c4", null ],
    [ "Close", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#aab0dfd0d1e1183b233ee5b3439facb41", null ],
    [ "CreateWindow", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a676ee6af2f4cb29cdbc2680844fa9e24", null ],
    [ "DrawQuad", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a25418c849e9d79317550aa6ec508ba3a", null ],
    [ "PopMatrix", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a503df496ac4fd11418349a3c4467f9e8", null ],
    [ "PushMatrix", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#ad3b61c7d9d0753911d65f9ca397f6c14", null ],
    [ "Run", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#ade9613645500accd5503719ac56eb4d4", null ],
    [ "SetColor", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#ab40acb972bff4866427639bd868191b8", null ],
    [ "SetScissor", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a61e30831cdd82761656557400fe855b9", null ],
    [ "ShowCursor", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a2337d511a67db028cc0cefd3ac111379", null ],
    [ "currentFps", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a58ebb85a0b031e23e51dfc787f59d008", null ],
    [ "height", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a7fc5e780dad566cf1e9cd778d3c459b5", null ],
    [ "targetFps", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#a6a399162f43058f85d91f56ce4aed899", null ],
    [ "width", "class_g_x_p_engine_1_1_core_1_1_g_l_context.html#ad4022898156e14f1da2286dfff0db75c", null ]
];