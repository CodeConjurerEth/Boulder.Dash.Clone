var class_tiled_map_parser_1_1_text =
[
    [ "ToString", "class_tiled_map_parser_1_1_text.html#a743b87a8dd38a8cc7937b8e709466a82", null ],
    [ "bold", "class_tiled_map_parser_1_1_text.html#ae72095900e7d8c7364e457b9fb63a26b", null ],
    [ "color", "class_tiled_map_parser_1_1_text.html#a5224792494f13e5859b669e158cc22c5", null ],
    [ "font", "class_tiled_map_parser_1_1_text.html#a8d47fe425c7aff85fef636405702ef35", null ],
    [ "fontSize", "class_tiled_map_parser_1_1_text.html#a7003744c35b5cd570a8f8a3fe2cfba79", null ],
    [ "horizontalAlign", "class_tiled_map_parser_1_1_text.html#a3ec0f2d5f93b5605a82b3d2b36db08b0", null ],
    [ "italic", "class_tiled_map_parser_1_1_text.html#a6a175109ce4bcfb9b6aa0467df94d9c8", null ],
    [ "text", "class_tiled_map_parser_1_1_text.html#a87eafe068738c73f730231a2c7de37db", null ],
    [ "verticalAlign", "class_tiled_map_parser_1_1_text.html#a66be0bc38a7230f8e33670f1d23fa176", null ],
    [ "wrap", "class_tiled_map_parser_1_1_text.html#a6a43fe206b4e36a342768f5a892a5bd8", null ],
    [ "Color", "class_tiled_map_parser_1_1_text.html#a692e43bdbf07ae5622d94b6ac079a49f", null ]
];