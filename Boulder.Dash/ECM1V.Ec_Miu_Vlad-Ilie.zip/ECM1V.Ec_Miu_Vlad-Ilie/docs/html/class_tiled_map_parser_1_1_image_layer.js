var class_tiled_map_parser_1_1_image_layer =
[
    [ "ToString", "class_tiled_map_parser_1_1_image_layer.html#a7faef9b4524c3ce8786411084593f6bf", null ],
    [ "Image", "class_tiled_map_parser_1_1_image_layer.html#ab71053325d3da9bfcf677ae63bc335b8", null ],
    [ "Name", "class_tiled_map_parser_1_1_image_layer.html#a31e152db6aaabf1cf2e08112bd22fb84", null ],
    [ "offsetX", "class_tiled_map_parser_1_1_image_layer.html#aee6fa237ec1e4f6d16e67ad858b513ca", null ],
    [ "offsetY", "class_tiled_map_parser_1_1_image_layer.html#a1f030cf1ee41ad2c16cb57d0a7a203c3", null ]
];