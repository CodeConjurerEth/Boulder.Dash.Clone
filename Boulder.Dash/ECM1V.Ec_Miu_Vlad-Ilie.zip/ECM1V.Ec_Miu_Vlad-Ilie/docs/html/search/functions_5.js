var searchData=
[
  ['inhierarchy_223',['InHierarchy',['../class_g_x_p_engine_1_1_game_object.html#ac86698b7fc977350b80ebfeabbf0f03a',1,'GXPEngine::GameObject']]],
  ['inverse_224',['Inverse',['../class_g_x_p_engine_1_1_transformable.html#a88aaee3768b8a31a8e702e23493ab1f0',1,'GXPEngine::Transformable']]],
  ['inversetransformdirection_225',['InverseTransformDirection',['../class_g_x_p_engine_1_1_transformable.html#a4f21f972dd76604f9dcf0c9d8756cf7f',1,'GXPEngine.Transformable.InverseTransformDirection()'],['../class_g_x_p_engine_1_1_game_object.html#a0e2649738d1c6d96f65e28ee3ac7fb1a',1,'GXPEngine.GameObject.InverseTransformDirection()']]],
  ['inversetransformpoint_226',['InverseTransformPoint',['../class_g_x_p_engine_1_1_transformable.html#a304e3841020c64ea07b21235b1642463',1,'GXPEngine.Transformable.InverseTransformPoint()'],['../class_g_x_p_engine_1_1_game_object.html#a56d3c636d0031ca94e2f368c1a9f05a7',1,'GXPEngine.GameObject.InverseTransformPoint()']]]
];
