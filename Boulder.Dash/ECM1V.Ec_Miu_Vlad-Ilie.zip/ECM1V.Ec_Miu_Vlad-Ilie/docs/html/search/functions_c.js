var searchData=
[
  ['setchildindex_243',['SetChildIndex',['../class_g_x_p_engine_1_1_game_object.html#aee5eda02a379782f6a1a6034c178fe71',1,'GXPEngine::GameObject']]],
  ['setcolor_244',['SetColor',['../class_g_x_p_engine_1_1_sprite.html#a1273156710bcf4143a80147a721a696d',1,'GXPEngine::Sprite']]],
  ['setframe_245',['SetFrame',['../class_g_x_p_engine_1_1_animation_sprite.html#ac1814eb56833aacf3ef62a93ed714fdd',1,'GXPEngine::AnimationSprite']]],
  ['setorigin_246',['SetOrigin',['../class_g_x_p_engine_1_1_sprite.html#a7f23dfc233b1a22c92ca548a5a6e7efc',1,'GXPEngine::Sprite']]],
  ['setscalexy_247',['SetScaleXY',['../class_g_x_p_engine_1_1_transformable.html#ac1fb7cad30e47d512c6e7ceeb9ae4e80',1,'GXPEngine.Transformable.SetScaleXY(float scaleX, float scaleY)'],['../class_g_x_p_engine_1_1_transformable.html#aead4d1f0fd78242a91318599ebfc1908',1,'GXPEngine.Transformable.SetScaleXY(float scale)']]],
  ['setviewport_248',['SetViewport',['../class_g_x_p_engine_1_1_game.html#afecde817f37c96e76d26593c7fcac853',1,'GXPEngine::Game']]],
  ['setxy_249',['SetXY',['../class_g_x_p_engine_1_1_transformable.html#a21fbd124df79d5fda5b98c49251cbdab',1,'GXPEngine::Transformable']]],
  ['showmouse_250',['ShowMouse',['../class_g_x_p_engine_1_1_game.html#a2f0f1eb7d0ba0c275deaef45421b8544',1,'GXPEngine::Game']]],
  ['sound_251',['Sound',['../class_g_x_p_engine_1_1_sound.html#a0f1aaede78ecba23937a82ed53272197',1,'GXPEngine::Sound']]],
  ['sprite_252',['Sprite',['../class_g_x_p_engine_1_1_sprite.html#a22b8dd09f5a35aa1a869ad37c995f3e5',1,'GXPEngine.Sprite.Sprite(System.Drawing.Bitmap bitmap, bool addCollider=true)'],['../class_g_x_p_engine_1_1_sprite.html#ac4e833f3e5fd010030fdbd1f55359a40',1,'GXPEngine.Sprite.Sprite(string filename, bool keepInCache=false, bool addCollider=true)']]],
  ['start_253',['Start',['../class_g_x_p_engine_1_1_game.html#a60cfaccee44dd4badd8629bcd9936beb',1,'GXPEngine::Game']]],
  ['stepdelegate_254',['StepDelegate',['../class_g_x_p_engine_1_1_game.html#a4d1f2cf034dc8d50480f94ea0da11fb4',1,'GXPEngine::Game']]],
  ['stop_255',['Stop',['../class_g_x_p_engine_1_1_sound_channel.html#aa398367364ddf786a89587ce1823ad42',1,'GXPEngine::SoundChannel']]]
];
